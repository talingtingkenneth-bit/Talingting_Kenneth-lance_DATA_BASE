package studentinformationsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    
    // 🚨 REPLACE "your_password" WITH YOUR ACTUAL MYSQL ROOT PASSWORD 🚨
    private static final String URL = "jdbc:mysql://localhost:3306/student_information_system";
    private static final String USER = "root";
    private static final String PASSWORD = "#justhappy123"; 
    
    public static Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("✅ Database Connected Successfully!");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("❌ Database Connection Failed!");
            e.printStackTrace();
        }
        return connection;
    }

    // We add this main method just to test the connection right now
    public static void main(String[] args) {
        getConnection();
    }
}